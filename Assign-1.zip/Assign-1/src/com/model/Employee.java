package com.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
 
@Entity
@Table(name="EMPLOYEES")
public class Employee  {
 
  
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="EMP_ID")
    private Long empId;
 
    private String name;
 
    private  String empBand;
    
    public Long getEmpId() {
  		return empId;
  	}

  	public void setEmpId(Long empId) {
  		this.empId = empId;
  	}

  	public String getName() {
  		return name;
  	}

  	public void setName(String name) {
  		this.name = name;
  	}

  	public String getEmpBand() {
  		return empBand;
  	}

  	public void setEmpBand(String empBand) {
  		this.empBand = empBand;
  	}

}