package com.client;

import java.util.List;

import com.dao.EmployeesDao;
import com.model.Employee;

public class Client {

	public static void main(String[] args) {
		 EmployeesDao empDao = new EmployeesDao();
		 
	        Employee emp = new Employee();
	        emp.setName("Babu");
	        emp.setEmpBand("B1");
	        empDao.insertEmployee(emp);
      
	        
	        System.out.println("List of Employees");
	        
	        List<Employee> empList = empDao.getEmployeeList();
	        System.out.println("emp size: "+empList.size());
	        empList.stream().forEach(System.out::println);
	        
	        System.out.println("Get Employee by Id");
	        
	        Employee empObj = empDao.getEmployeeById(emp.getEmpId());
	        System.out.println(empObj);
	        
	        System.out.println("Update Employee by Id");
	        
	       empDao.updateEmployee(emp.getEmpId(), emp);
	        
	        
	        System.out.println("Delete Employee");
	        empDao.deleteEmployee(empObj);
	        
	        
	}

}
