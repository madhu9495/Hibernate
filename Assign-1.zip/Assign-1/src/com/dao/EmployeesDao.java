package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import com.model.Employee;

public class EmployeesDao {
	
	public List<Employee> getEmployeeList(){
		 
        Session session = null;
        List<Employee> empList = null;
        try {
            session = HibernateUtil.getSession();
            String queryStr = "select emp from Employee emp";
            Query query = session.createQuery(queryStr);
            empList = query.list();
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
        return empList;
    }
 
    public Employee getEmployeeById(Long empId){
 
        Session session = null;
        Employee emp = null;
        try {
            session = HibernateUtil.getSession();
            String queryStr = "select emp from Employee emp";
            emp = session.get(Employee.class, empId);
 
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
        return emp;
    }
 
    public void insertEmployee(Employee emp) {
 
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getSession();
            transaction = session.beginTransaction();
            session.save(emp);
            System.out.println("inserted employee: "+emp.getName());
            transaction.commit();
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
    }
 
    public void deleteEmployee(Employee emp) {
 
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getSession();
            transaction = session.beginTransaction();
            session.delete(emp);
            transaction.commit();
            System.out.println("deleted employee: "+emp.getName());
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
    }
    
    public void updateEmployee(long id, Employee emp){
        if(id <=0)  {
            System.out.println("emp id not found"); 
        }
        else{
        Session session = null;
        Transaction transaction = null;
        try {
        session = HibernateUtil.getSession();
        transaction = session.beginTransaction();
           String hql = "update Employee set name = :name, band=:band where id = :id";
           Query query = session.createQuery(hql);
           query.setInteger("id",id);
           query.setString("name",emp.getName());
           query.setInteger("band",emp.getEmpBand());
           int rowCount = query.executeUpdate();
           if(rowCount==1){
        	   System.out.println("Rows affected: " + rowCount);
        	   transaction.commit();
           }
           else{
        	   System.out.println("record not updated ");
           }
           
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
          
           session.close();
        } 
   }

}
