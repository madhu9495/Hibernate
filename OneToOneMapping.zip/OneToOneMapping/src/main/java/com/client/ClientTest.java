package com.client;


import com.entities.Passport;
import com.entities.Employee;
import com.util.DaoImpl;;


public class ClientTest {

	public static void main(String[] args) {
		
		DaoImpl Dao = new DaoImpl();
		
		Employee employee= new Employee();
		employee.setEmployeeName("Messy");
		employee.setEmail("Messy.007@gmail.com");
		employee.setSalary(51000.00);
		
		
		Passport passport = new Passport();
		passport.setPincode("500052");
		passport.setState("Hyderabad");
		passport.setCountry("India");
		
		employee.setPassport(passport);
		
		Dao.addEmployee(employee);
		
		Dao.DeleteEmployee(employee);
		
	}
	    
	  }

