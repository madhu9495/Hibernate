package com.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passport_table")
public class Passport {

	@Id
	@Column(name="passport_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer passportId;
	
	@Column(name = "pin_code",length=50)
    private String pincode;
    @Column(name = "state_name")
    private String state;
    @Column(name = "country_name")
    private String country;
	
	public Integer getPassportId() {
		return passportId;
	}


	public void setPassportId(Integer passportId) {
		this.passportId = passportId;
	}


	public String getPincode() {
		return pincode;
	}


	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	
    
	
	@Override
	public String toString() {
		return "Passport [passportId=" + passportId + ", address=" + pincode + ", state=" + state + ", country=" + country + "]";
	}
}
