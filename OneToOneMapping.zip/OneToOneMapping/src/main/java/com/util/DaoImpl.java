package com.util;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entities.Employee;

public class DaoImpl {
	
	public void addEmployee(Employee e){
		
		Session session = null;
		Transaction tx = null;
		try {
        session = SessionUtil.getSession();        
         tx = session.beginTransaction();
        session.save(e);
        tx.commit();
        System.out.println("Record created Successfully");
		}
		catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(tx != null) tx.rollback();
            System.out.println("Record Could not created");
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
        
    }
	
	public void DeleteEmployee(Employee e) {
		Session session = null;
		Transaction tx = null;
		try {
        session = SessionUtil.getSession();        
         tx = session.beginTransaction();
        session.delete(e);
        tx.commit();
        System.out.println("Record Deleted Successfully");
		}
		catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(tx != null) tx.rollback();
            System.out.println("Record Could not Delete");
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
		
	}

}
