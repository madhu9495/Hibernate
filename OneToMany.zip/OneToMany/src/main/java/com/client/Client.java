package com.client;


import java.util.HashSet;
import java.util.Set;

import com.util.DaoImpl;
import com.entities.Department;
import com.entities.Employee;


public class Client {

	public static void main(String[] args) {
		
		DaoImpl Dao=new DaoImpl();
		
		System.out.println("Creating Department and Employees");
		
		Department dept = new Department("IT");
		
		Employee emp1= new Employee("Ram", 30000);
		Employee emp2= new Employee("Arjun", 32000);
		Set<Employee> EmpSet = new HashSet<Employee>();
		EmpSet.add(emp1);
		EmpSet.add(emp2);
		
		dept.SetEmployee(EmpSet);
		
		Dao.createDepartment(dept);
		
		System.out.println("Delete Department");
		
		Dao.DeleteDepartment(dept);
	}

}
