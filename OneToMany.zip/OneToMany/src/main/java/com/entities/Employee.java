package com.entities;




import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="employee_table2")
public class Employee {

	@Id
	@Column(name="employee_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(name="employee_name")
    private String name;
	
	@Column(name="employee_salary")
    private long salary;
	
public Employee(){
    	
    }
    
    public Employee(String name, long salary){
    	
    	this.name = name;
    	this.salary = salary;
    	
    }

    public int getId() {
        return id;
    }
    
    public void setId(int id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }

    public long getSalary() {
        return salary;
    }

    public void setSalary(long salary) {
        this.salary = salary;
    }

    public String toString() {
        return "EmployeeId: " + getId() + " name: " + getName() + 
               " salary " + getSalary();
    }

}
