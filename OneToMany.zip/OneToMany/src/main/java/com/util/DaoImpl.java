package com.util;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.SessionUtil;

import com.entities.Department;

public class DaoImpl {
	
	public void createDepartment(Department dept) {
		
		Session session = null;
		Transaction transaction = null;
		try {
        session = SessionUtil.getSession();
        transaction = session.beginTransaction();
	    session.save(dept);
	    transaction.commit();
	    System.out.println("Record created Successfully");
		}
		catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
            System.out.println("Record Could not created");
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
		
	  }
	
	public void DeleteDepartment(Department dept){
		Session session = null;
        Transaction transaction = null;
        try {
            session = SessionUtil.getSession();
            transaction = session.beginTransaction();
            session.delete(dept);
            transaction.commit();
            System.out.println("deleted Department: "+dept.getId());
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
            System.out.println("Unable to delete: "+dept.getId());
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
    }
		
		
	}
	
	
	
	
